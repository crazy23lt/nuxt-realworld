import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _dd22932e = () => interopDefault(import('..\\pages\\layout\\default.vue' /* webpackChunkName: "" */))
const _24d3f8dc = () => interopDefault(import('..\\pages\\home\\home.vue' /* webpackChunkName: "" */))
const _148ed2a4 = () => interopDefault(import('..\\pages\\auth\\auth.vue' /* webpackChunkName: "" */))
const _33006804 = () => interopDefault(import('..\\pages\\profile\\profile.vue' /* webpackChunkName: "" */))
const _5d17b044 = () => interopDefault(import('..\\pages\\setting\\setting.vue' /* webpackChunkName: "" */))
const _4f4af738 = () => interopDefault(import('..\\pages\\editor\\editor.vue' /* webpackChunkName: "" */))
const _0cc43ac4 = () => interopDefault(import('..\\pages\\article\\article.vue' /* webpackChunkName: "" */))
const _1eaaff4a = () => interopDefault(import('..\\pages\\404.vue' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _dd22932e,
    children: [{
      path: "/",
      component: _24d3f8dc,
      name: "home"
    }, {
      path: "/login",
      component: _148ed2a4,
      name: "login"
    }, {
      path: "/register",
      component: _148ed2a4,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _33006804,
      name: "profile"
    }, {
      path: "/settings",
      component: _5d17b044,
      name: "settings"
    }, {
      path: "/editor",
      component: _4f4af738,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _0cc43ac4,
      name: "article"
    }, {
      path: "*",
      component: _1eaaff4a,
      name: "404"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
